<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Step Two</title>
    <link rel="stylesheet" href="{{ asset('all/all.css') }}">
    <link rel="stylesheet" href="{{ asset('user/stepOne.css') }}">
    <link rel="stylesheet" href="{{ asset('user/stepTwo.css') }}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />


</head>
<body>
    
    <div class="step">
        <div class="stepWrapper">
            <div class="box-step">
                <h3 style="background-color: green;" class="isabida mb-3">1</h3>
                <h3 style="background-color: green;" class="isabida mb-3">2</h3>
                <h3 class="isabida mb-3">3</h3>
                
            </div>

            <div class="box-step1 mt-2">
                <img src="{{ asset('image/cute.png') }}" alt="">
            </div>

            <div class="box-step2">
                <div class="stepHeader">
                    <img class="img5 mb-2" src="{{ asset('image/profile.png') }}" alt="">
                    <p class="p1"><span>SHS Alumni Profiling System </span><br>Personal Information</p>
                </div>
                <form action="{{ route('user-userProfile') }}" method="post">
                    @csrf
                    <div class="twoFlex">
                        <div class="box">
                            <label for="">First name</label><br>
                            <input style="text-transform: uppercase;" type="text" name="firstname" require>
                            <p style="color: red" >@error('firstname'){{ $message }}@enderror</p>
                        </div>
                        <div class="box">
                            <label for="">Last name</label><br>
                            <input style="text-transform: uppercase;" type="text" name="lastname" required>
                            <p style="color: red" >@error('lastname'){{ $message }}@enderror</p>
                        </div>
                    </div>
                    <div class="single-box">
                        <label for="">Middle name</label><br>
                        <input style="text-transform: uppercase;" type="text" name="middlename" required>
                        <p style="color: red" >@error('middlename'){{ $message }}@enderror</p>
                    </div>
                    <div class="single-box">
                        <label for="">Date of birth</label><br>
                        <input style="text-transform: uppercase;" type="date" name="birth" required>
                        <p style="color: red" >@error('birth'){{ $message }}@enderror</p>
                    </div>
                    <div class="twoFlex">
                        <div class="box">
                            <label for="gender">Gender</label><br>
                            <select name="gender" id="" required>
                                <option value="">-- Select --</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                            <p style="color: red" >@error('gender'){{ $message }}@enderror</p>
                        </div>
                        <div class="box">
                            <label for="">Status</label><br>
                            <select name="selfStatus" id="" required>
                                <option value="">-- Select --</option>
                                <option value="Single">Single</option>
                                <option value="Married">Married</option>
                            </select>
                            <p style="color: red" >@error('selfStatus'){{ $message }}@enderror</p>
                        </div>
                    </div>
                    <button style="float: right;" type="submit" class="btn btn-primary btn-sm mt-3"> <i class="fa-solid fa-user mt-2"></i>  Save Information</button>
                </form>
            </div>
        </div>
    </div>

</body>
</html>