<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Users</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="{{ asset('all/all.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/admin-userUpdate.css') }}">
</head>
<body>

    <div class="userUpdate">
        <div class="update">
            <div class="conUp">
                <img src="{{ asset('image/cute.png') }}" alt="">
            </div>
            <div class="conUp2">
                <a href="{{ route('admin-adminHome') }}" class="btn btn-primary btn-sm mt-2">Main Dashboard </a>
                <a href="{{ route('admin-adminUser') }}" class="btn btn-primary btn-sm mt-2">Users table </a>
                <p class="p1 mt-3 mb-3">*Update alumni account here</p>
                @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif
                <form action="{{ route('admin-userUpdate') }}" method="post">
                    @csrf
                    <label for="">Username</label>
                    <input style="text-transform: uppercase;" type="hidden" name="id" value="{{ $users->id }}">
                    <input style="text-transform: uppercase;" type="text" name="username" value="{{ $users->username }}">
                    <p style="color: red" >@error('username'){{ $message }}@enderror</p>
                    <label for="">Password</label>
                    <input style="text-transform: uppercase;" type="text" name="password">
                    <p style="color: red" >@error('password'){{ $message }}@enderror</p>

                    <button type="submit" class="btn btn-success btn-sm mt-2">Create Save</button>

                </form>
            </div>
        </div>
    </div>
    
</body>
</html>