<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="{{ asset('all/all.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/settings.css') }}">
</head>
<body>
    

    <div class="setings-con">
        <div class="set">
            
            <a href="{{ route('admin-adminHome') }}" class="btn btn-primary btn-sm mb-4"><i class="fa-solid fa-backward"></i></a>
            
            @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif
            <form action="{{ route('admin-newPass') }}" method="post">
                @csrf
                <div class="single-box">
                    <label for="">Username</label><br>
                    <input type="text" value="{{ $users->username }}"  name="username">
                    <p style="color: red" id="proceedErrorMessage">@error('username'){{ $message }}@enderror</p>
                </div>

                <div class="single-box">
                    <label for="">New Password</label><br>
                    <input style="text-transform: uppercase;" type="password" name="password" value="{{ old('password') }}">
                    <p style="color: red" id="proceedErrorMessage">@error('password'){{ $message }}@enderror</p>
                </div>

                <div class="single-box">
                    <label for="">Repeat Password</label><br>
                    <input style="text-transform: uppercase;" type="password" name="repeatPassword" value="{{ old('repeatPassword') }}">
                    <p style="color: red" id="proceedErrorMessage">@error('repeatPassword'){{ $message }}@enderror</p>
                </div>
                
                <button style="float: right;" type="submit" class="btn btn-success btn-sm">Save</button>
            </form>
           <div class="newmail">
                <form action="{{ route('admin-saveEmail') }}" method="post">
                    @csrf
                    <div class="single-box mt-4">
                        <label for="">Email</label><br>
                        <input type="email" value="{{ $contact->gmail }}"  name="email">
                        <p style="color: red" id="proceedErrorMessage">@error('email'){{ $message }}@enderror</p>
                    </div>
                    
                    <button style="float: right;" type="submit" class="btn btn-success btn-sm">Save</button>
                </form>
           </div>
        </div>
    </div>

</body>
</html>