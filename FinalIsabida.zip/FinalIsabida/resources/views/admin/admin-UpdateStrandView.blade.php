<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Strand</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="{{ asset('all/all.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/admin-userUpdate.css') }}">
</head>
<body>

    <div class="userUpdate">
        <div class="update">
            <div class="conUp">
                <img src="{{ asset('image/cute.png') }}" alt="">
            </div>
            <div class="conUp2">
                <a href="{{ route('admin-adminHome') }}" class="btn btn-primary btn-sm mt-2">Main Dashboard </a>
                <a href="{{ route('admin-adminStrand') }}" class="btn btn-primary btn-sm mt-2">Strand table </a>
                <p class="p1 mt-3 mb-3">*Create Strand Here</p>
                
                @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif
                <form action="{{ route('admin-newStrand') }}" method="post">
                    @csrf
                    <label for="">Acronym</label>
                    
                    <input style="text-transform: uppercase;" type="hidden" name="id" value="{{ $strand->id }}">
                    <input style="text-transform: uppercase;" type="text" name="acronym" value="{{ $strand->acronym }}">
                    
                    <p style="color: red" >@error('acronym'){{ $message }}@enderror</p>
                    <label for="">Strand Name</label>
                    <input style="text-transform: uppercase;" type="text" name="strand" value="{{ $strand->strand }}">
                    
                    <p style="color: red" >@error('strand'){{ $message }}@enderror</p>
                    <button type="submit" class="btn btn-success btn-sm mt-2">Create Save</button>
                </form>
            </div>
        </div>
    </div>
    
</body>
</html>