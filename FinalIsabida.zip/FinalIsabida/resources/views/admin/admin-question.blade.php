<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Question</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="{{ asset('all/all.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/question.css') }}">
</head>
<body>




    <div class="question">  

    
        <div class="bgq">

        </div>
        

        <div class="questionWrapper">
            <div class="head-q">
                <a href="{{ route('admin-adminHome') }}" class="btn btn-primary btn-sm mt-2"><i class="fa-solid fa-house"></i> Main Dashboard </a>
                <!-- <button id="printButton" class="btn btn-success btn-sm mt-2"><i class="fa-solid fa-print"></i> Print Result</button> -->
            </div>

            <p class="p3">STRAND-WISE EDUACTION STATUS REPORT</p>
            <table class="mt-1 tblData" id="printTable">
                <tr>
                    <th>Strand Name</th>
                    <th>Active Users</th>
                    <th>Go College</th>
                    <th>Stop Schooling</th>
                    <th>Related</th>
                    <th>Not Related</th>
                    <th>View Grapth</th>
                </tr>
                @foreach ($strandCounts as $strand)
                    <tr>
                        <td>{{ $strand->strand_name }}</td>
                        <td>{{ $strand->total_users }}</td>
                        <td>{{ $strand->proceed_yes }}</td>
                        <td>{{ $strand->stop_schooling }}</td>
                        <td>{{ $strand->related_yes }}</td>
                        <td>{{ $strand->not_related }}</td>
                        <td><a href="{{ route('admin-reportView', ['name' => $strand->strand_name]) }}" class="btn btn-success btn-sm"><i class="fa-solid fa-signal"></i> Grapth</button></td>
                    </tr>
                @endforeach
                
            </table>

            <p class="p3 mt-4">SENIOR HIGH SCHOOL GRADUATES, COLLEGES ENROLLMENT STATUS</p>
            <table class="mt-3 tblData" id="printTable">
                <tr>
                    <th>Number of students enrolled in GCC</th>
                    <th>Number of students who didn't enroll in GCC</th>
                    <th>Operation</th>
                </tr>
                <tr>
                    <td>{{ $enrolledCount }}</td>
                    <td>{{ $notEnrolledCount }}</td>
                    <td><a href="{{ route('admin-reportView2') }}" class="btn btn-success btn-sm"><i class="fa-solid fa-signal"></i> Grapth</button></td>
                </tr>
            </table>


            <p class="p3 mt-4">GCC SENIOR HIGH GRADUATES' COURSE CHOICES</p>
            <a href="{{ route('admin-reportView3') }}" class="btn btn-success btn-sm"><i class="fa-solid fa-signal"></i> Grapth</a>
            
            <table class="mt-3 tblData" id="printTable">
                <tr>
                    <th>Course name</th>
                    <th>Number of student enroll</th>
                </tr>
                @foreach ($countYesCourses as $course)
                <tr>
                    <td>{{ $course->course }}</td>
                    <td>{{ $course->count }}</td>
                </tr>
                @endforeach
            </table>

            


        </div>

        <script>
            document.getElementById("printButton").addEventListener("click", function() {
                var tableToPrint = document.getElementById("printTable");
                var printWindow = window.open('', '', 'width=800,height=600'); // Adjust width and height as needed
                printWindow.document.open();
                printWindow.document.write('<html><head><title>Print</title></head><body>');
                printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; }</style>'); // Add styles if needed
                printWindow.document.write(tableToPrint.outerHTML);
                printWindow.document.write('</body></html>');
                printWindow.document.close();
                printWindow.print();
                printWindow.close();
            });
        </script>







    </div>
    
</body>
</html>