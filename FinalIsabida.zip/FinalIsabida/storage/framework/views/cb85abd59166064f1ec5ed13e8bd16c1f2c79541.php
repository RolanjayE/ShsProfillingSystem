<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Step Three</title>
    <link rel="stylesheet" href="<?php echo e(asset('all/all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/stepOne.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/stepTwo.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/stepThree.css')); ?>">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />


</head>
<body>


    
    <div class="step">
        <div class="stepWrapper">
            <div class="box-step">
                <h3 style="background-color: green;" class="isabida mb-3">1</h3>
                
                <h3 style="background-color: green;" class="isabida mb-3">2</h3>
                <h3 style="background-color: green;" class="isabida mb-3">3</h3>
                <h3 class="isabida mb-3">4</h3>
            </div>

            <div class="box-step1 mt-2">
                <img src="<?php echo e(asset('image/isabida.png')); ?>" alt="">
            </div>

            <div class="box-step2">
                <div class="stepHeader">
                    <img class="img5 mb-2" src="<?php echo e(asset('image/profile.png')); ?>" alt="">
                    <p class="p1"><span>SHS Alumni Profiling System</span><br>Related Information</p>
                </div>

                <?php if($asks->collegeName == 'yes'): ?>
                    <form action="<?php echo e(route('user-userCourse')); ?>" method="post">

                        <?php echo csrf_field(); ?>
                        <label for=""> Which course are you enrolled in at GCC ?</label>
                        <input type="hidden" value="yes" name="answer">
                        <select name="course" class="mt-2" name="" id="">
                            <option value="">-- Select --</option>
                            <option value="Bachelor of Science in Information Technology">Bachelor of Science in Information Technology (BSIT)</option>
                            <option value="Bachelor of Science in Office Administration ">Bachelor of Science in Office Administration (BSOA)</option>
                            <option value="Bachelor of Science in Business Administration">Bachelor of Science in Business Administration (BSBA)</option>
                            <option value="Bachelor of Science in Criminology">Bachelor of Science in Criminology (BSCrim)</option>
                        </select>

                        <p style="color: red" id="relatedErrorMessage"><?php $__errorArgs = ['course'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                        <button style="float: right;" type="submit" class="btn btn-primary btn-sm mt-4"> <i class="fa-solid fa-user mt-2"></i>  Save Information</button>
                    </form>
                <?php else: ?>
                    <form action="<?php echo e(route('user-userCourse')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" value="no" name="answer">
                        <label for=""> What course are you currently enrolled in ? </label>
                        <input type="text" placeholder="Ex. Bachelor of science technology" name="course">
                        
                        <p style="color: red" id="relatedErrorMessage"><?php $__errorArgs = ['course'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                        <button style="float: right;" type="submit" class="btn btn-primary btn-sm mt-4"> <i class="fa-solid fa-user mt-2"></i>  Save Information</button>
                    </form>
                <?php endif; ?>
                
            </div>
        </div>
    </div>


</body>
</html><?php /**PATH C:\FinalIsabida\resources\views/user/user-usertAlertFour.blade.php ENDPATH**/ ?>