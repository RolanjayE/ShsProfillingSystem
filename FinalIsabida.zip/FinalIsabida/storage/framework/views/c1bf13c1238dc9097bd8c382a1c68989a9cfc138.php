<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main Page</title>
    <link rel="stylesheet" href="<?php echo e(asset('all/all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/home.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/main.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>

    <div class="home-con">
        <?php if (isset($component)) { $__componentOriginal917044b2726c310fe04ba7b5efd2d1225d61f37c = $component; } ?>
<?php $component = App\View\Components\UserHeader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('userHeader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\UserHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal917044b2726c310fe04ba7b5efd2d1225d61f37c)): ?>
<?php $component = $__componentOriginal917044b2726c310fe04ba7b5efd2d1225d61f37c; ?>
<?php unset($__componentOriginal917044b2726c310fe04ba7b5efd2d1225d61f37c); ?>
<?php endif; ?>
        <div class="bg">
        </div>

        <div class="home-wrapper">
            <div class="home-left">
                <?php if($profiles->profile != ""): ?>
                    <img id="profileImage" class="img4 mb-2" src="<?php echo e(asset('storage/photos/' . $profiles->profile)); ?>" alt="Profile Photo">
                <?php else: ?>
                    <img class="img4 mb-2" id="profileImage" src="<?php echo e(asset('image/profile.png')); ?>" alt="">
                <?php endif; ?>
                    <div class="user-data">
                    <p class="p4"><?php echo e($profiles->firstname); ?> <?php echo e($profiles->lastname); ?></p>
                    <p class="p1">@ GINGOOG CITY COLLEGES <br> @ <?php echo e($strand->strand); ?> <br> @ <?php echo e($ask->year); ?></p>
                    <a href="<?php echo e(route('user-home')); ?>" class="btn btn-success btn-sm mt-2"><i class="fa-solid fa-user mt-2"></i> Information</a>
                </div>
            </div>
            <div class="home-right">
                <div class="head-search">
                    
                    <p>@ <?php echo e($strand->strand); ?></p>
                    <input type="search" name="" id="searchInput" placeholder="Search name">
                </div>


                <div class="box-content">
                    <?php $__currentLoopData = $profileSpecials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profileSpecial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="cBox">
                        <div class="img">
                        <?php if($profileSpecial->profile != ""): ?>
                            <img id="profileImage" class="img5 mb-2" src="<?php echo e(asset('storage/photos/' . $profileSpecial->profile)); ?>" alt="Profile Photo">
                        <?php else: ?>
                            <img class="img5 mb-2" id="profileImage" src="<?php echo e(asset('image/profile.png')); ?>" alt="">
                        <?php endif; ?>
                        </div>
                        <div class="info">
                            <p class="p5"><?php echo e($profileSpecial->firstname); ?> <?php echo e($profileSpecial->middlename); ?> <?php echo e($profileSpecial->lastname); ?></p>
                        </div>
                    </div> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
            </div>
        </div>

        
    </div>



    <script>
        // Get references to the search input and all cBox elements
        const searchInput = document.getElementById('searchInput');
        const cBoxElements = document.querySelectorAll('.cBox');

        // Add an event listener to the search input to filter and display elements
        searchInput.addEventListener('input', () => {
            const searchValue = searchInput.value.toLowerCase();
            
            cBoxElements.forEach((cBoxElement) => {
                const pElement = cBoxElement.querySelector('.p5');
                if (pElement) {
                    const textContent = pElement.textContent.toLowerCase();
                    const shouldDisplay = textContent.includes(searchValue);
                    cBoxElement.style.display = shouldDisplay ? 'flex' : 'none';
                }
            });
        });
    </script>

    
</body>
</html><?php /**PATH C:\FinalIsabida\resources\views/user/user-userHomeMain.blade.php ENDPATH**/ ?>