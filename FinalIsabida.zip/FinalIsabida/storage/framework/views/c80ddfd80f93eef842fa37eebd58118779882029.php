<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Step Three</title>
    <link rel="stylesheet" href="<?php echo e(asset('all/all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/stepOne.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/stepTwo.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/stepThree.css')); ?>">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />


</head>
<body>


    
    <div class="step">
        <div class="stepWrapper">
            <div class="box-step">
                <h3 style="background-color: green;" class="isabida mb-3">1</h3>
                <h3 class="isabida mb-3">2</h3>
            </div>

            <div class="box-step1 mt-2">
                <img src="<?php echo e(asset('image/isabida.png')); ?>" alt="">
            </div>

            <div class="box-step2">
                <div class="stepHeader">
                    <img class="img5 mb-2" src="<?php echo e(asset('image/profile.png')); ?>" alt="">
                    <p class="p1"><span>SHS Alumni Profiling System</span><br>Related Information</p>
                </div>
                <form action="<?php echo e(route('user-userAsk')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="single-box">
                        <label for="">Strand </label><br>
                        <select name="strand" id="">
                            <option value="">-- Select --</option>
                            <?php $__currentLoopData = $strands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $strand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($strand->id); ?>"> <?php echo e($strand->strand); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <p style="color: red" ><?php $__errorArgs = ['strand'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                    </div>
                    <div class="single-box">
                        <label for="">Year Graduate</label><br>
                        <select name="year" id="yearSelect">
                            <option value="">-- Select --</option>
                        </select>
                        <p style="color: red" ><?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                    </div>

                    <div class="single-box">
                        <label for="">Did you proceed to college ?</label><br>
                        <select name="proceed" id="proceedSelect">
                            <option value="">-- Select --</option>
                            <option value="yes">Yes</option>
                            <option value="no">No</option>
                        </select>
                        <p style="color: red" id="proceedErrorMessage"><?php $__errorArgs = ['proceed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                    </div>

                    <div class="showThis" id="collegeInfo">

                        <div class="single-box">
                            <label for="">Did you enroll in Gingoog City Colleges?"</label><br>
                            <select id="relatedSelect" onchange="toggleCollegeNameInput()">
                                <option value="">-- Select --</option>
                                <option value="yes">Yes</option>
                                <option value="no">No</option>
                            </select>
                            <p style="color: red" id="relatedErrorMessage"><?php $__errorArgs = ['related'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                        </div>

                        <div class="single-box" id="collegeNameDiv" style="display: none;">
                            <label for="">Name of School</label><br>
                            <input name="collegeName" style="text-transform: uppercase;" type="text">
                            <p style="color: red" id="collegeNameErrorMessage"><?php $__errorArgs = ['collegeName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                        </div>

                        <div class="single-box">
                            <label for="">Is your STRAND related to a course in college?</label><br>
                            <select name="related" id="relatedSelect">
                                <option value="">-- Select --</option>
                                <option value="yes">Yes</option>
                                <option value="no">No</option>
                            </select>
                            <p style="color: red" id="relatedErrorMessage"><?php $__errorArgs = ['related'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                        </div>
                    </div>
                    
                    <button style="float: right;" type="submit" class="btn btn-primary btn-sm mt-2"> <i class="fa-solid fa-user mt-2"></i>  Save Information</button>
                </form>
            </div>
        </div>
    </div>
    <script>
    // Get references to the select elements
    const proceedSelect = document.getElementById('proceedSelect');
    const relatedSelect = document.getElementById('relatedSelect');

    // Get references to the error message paragraphs
    const proceedErrorMessage = document.getElementById('proceedErrorMessage');
    const collegeNameErrorMessage = document.getElementById('collegeNameErrorMessage');
    const relatedErrorMessage = document.getElementById('relatedErrorMessage');

    // Get reference to the collegeInfo div
    const collegeInfoDiv = document.getElementById('collegeInfo');

    // Initially hide the collegeInfo div
    collegeInfoDiv.style.display = 'none';

    // Add an event listener to the proceed select element
    proceedSelect.addEventListener('change', function () {
        // Hide or show the collegeInfo div based on the selected value
        if (proceedSelect.value === 'yes') {
            collegeInfoDiv.style.display = 'block';
        } else {
            collegeInfoDiv.style.display = 'none';
        }

        // Clear any error messages
        proceedErrorMessage.textContent = '';
        collegeNameErrorMessage.textContent = '';
        relatedErrorMessage.textContent = '';
    });
</script>
<script>
// Get a reference to the select element
const yearSelect = document.getElementById('yearSelect');

// Get the current year and subtract 1
const currentYear = new Date().getFullYear() - 1;

// Generate options for years starting from 2017 to the current year
for (let year = 2017; year <= currentYear; year++) {
    const option = document.createElement('option');
    option.value = year;
    option.textContent = year;
    yearSelect.appendChild(option);
}
</script>
<script>
    function toggleCollegeNameInput() {
        var selectElement = document.getElementById("relatedSelect");
        var collegeNameDiv = document.getElementById("collegeNameDiv");

        if (selectElement.value === "yes") {
            collegeNameDiv.style.display = "none";
        } else {
            collegeNameDiv.style.display = "block";
        }
    }
</script>




</body>
</html><?php /**PATH C:\FinalIsabida\resources\views/user/user-usertAlertThree.blade.php ENDPATH**/ ?>