<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Users</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo e(asset('all/all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/admin-userUpdate.css')); ?>">
</head>
<body>

    <div class="userUpdate">
        <div class="update">
            <div class="conUp">
                <img src="<?php echo e(asset('image/cute.png')); ?>" alt="">
            </div>
            <div class="conUp2">
                <a href="<?php echo e(route('admin-adminHome')); ?>" class="btn btn-primary btn-sm mt-2">Main Dashboard </a>
                <a href="<?php echo e(route('admin-adminUser')); ?>" class="btn btn-primary btn-sm mt-2">Users table </a>
                <p class="p1 mt-3 mb-3">*Update alumni account here</p>
                <?php if(session('success')): ?><div class="alert alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>
                <form action="<?php echo e(route('admin-userUpdate')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <label for="">Username</label>
                    <input style="text-transform: uppercase;" type="hidden" name="id" value="<?php echo e($users->id); ?>">
                    <input style="text-transform: uppercase;" type="text" name="username" value="<?php echo e($users->username); ?>">
                    <p style="color: red" ><?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                    <label for="">Password</label>
                    <input style="text-transform: uppercase;" type="text" name="password">
                    <p style="color: red" ><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>

                    <button type="submit" class="btn btn-success btn-sm mt-2">Create Save</button>

                </form>
            </div>
        </div>
    </div>
    
</body>
</html><?php /**PATH C:\FinalIsabida\resources\views/admin/admin-adminUserUpdate.blade.php ENDPATH**/ ?>