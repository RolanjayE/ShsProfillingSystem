<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="<?php echo e(asset('all/all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/home.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    

    <div class="home-con">

        <div class="wrapper">
            <div class="home">

                <div class="home-left">
                    <i id="tog" class="fa-solid fa-square-caret-down menuIcon"></i>
                    <div class="home-menu show">
                        <li><a style="background-color: white;" href="<?php echo e(route('admin-adminHome')); ?>"><i class="fa-solid fa-user"></i> Mian Dashboard</a></li>
                        <li><a href="#personal"><i class="fa-solid fa-user"></i> Personal</a></li>
                        <li><a href="#contact"><i class="fa-solid fa-address-book"></i> Contact</a></li>
                        <li><a href="#Background"><i class="fa-solid fa-graduation-cap"></i> Background</a></li>
                        <li><a href="#Question"><i class="fa-solid fa-circle-question"></i> Question</a></li>
                        <!-- <li><a href="#account"><i class="fa-solid fa-lock-open"></i></i> Account</a></li> -->
                    </div>
                    
                </div>

                <div class="home-right">
                    <div class="home-right-con">
                        <p class="p2">Profile</p>
                        <div class="form-profile" id="personal">

                            <div class="conProfile">
                                <?php if($profile->profile != ""): ?>
                                    <img id="profileImage" class="img1 mb-2" src="<?php echo e(asset('storage/photos/' . $profile->profile)); ?>" alt="Profile Photo">
                                <?php else: ?>
                                    <img class="img1 mb-2" id="profileImage" src="<?php echo e(asset('image/profile.png')); ?>" alt="">
                                <?php endif; ?>
                                <form method="POST" action="<?php echo e(route('admin-uploadProfile')); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <input style="text-transform: uppercase;" type="hidden" value="<?php echo e($id); ?>" name="id">
                                    <input style="width: 114px;" type="file" id="imageInput" accept="image/*" onchange="updateImage()" name="photo">
                                    <br>
                                    <button type="submit" class="btn btn-primary btn-sm mt-2">Save Changes</button>
                                </form>
                            </div>

                            <form action="<?php echo e(route('admin-addPersonal')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php if(session('success')): ?><div class="alert alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>
                                <p class="warning">* You can change your personal information here!</p>
                             
                                <input style="text-transform: uppercase;" type="hidden" value="<?php echo e($id); ?>" name="id">
                                <div class="twoFlex">
                                    <div class="box">
                                        <label for="">First name</label><br>
                                        <input style="text-transform: uppercase;" type="text" value="<?php echo e($profile->firstname); ?>" name="firstname">
                                    </div>
                                    <div class="box">
                                        <label for="">Last name</label><br>
                                        <input style="text-transform: uppercase;" type="text" value="<?php echo e($profile->lastname); ?>" name="lastname">
                                    </div>
                                </div>
                                <div class="single-box">
                                    <label for="">Middle name</label><br>
                                    <input style="text-transform: uppercase;" type="text" value="<?php echo e($profile->middlename); ?>" name="middlename">
                                </div>
                                <div class="single-box">
                                    <label for="">Date of birth</label><br>
                                    <input style="text-transform: uppercase;" type="date" value="<?php echo e($profile->birth); ?>" name="birth">
                                </div>
                                <div class="twoFlex">
                                    <div class="box">
                                        <label for="">Gender</label><br>
                                        <select name="gender" id="">
                                            <option value="<?php echo e($profile->gender); ?>"><?php echo e($profile->gender); ?></option>
                                            <option value="">Male</option>
                                            <option value="">Female</option>
                                        </select>
                                    </div>
                                    <div class="box">
                                        <label for="">Status</label><br>
                                        <select name="selfStatus" id="">
                                            <option value="<?php echo e($profile->selfStatus); ?>"><?php echo e($profile->selfStatus); ?></option>
                                            <option value="">Single</option>
                                            <option value="">Married</option>
                                        </select>
                                    </div>
                                </div>
                                <button style="float: right;" type="submit" class="btn btn-primary btn-sm">Save Changes</button>
                            </form>
                        </div>

                    </div>

                    <div class="contact" id="contact">
                        <p class="p2">Contact</p>
                        <div class="form-contact">
                            <form action="<?php echo e(route('admin-addContact')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                
                                <input style="text-transform: uppercase;" type="hidden" value="<?php echo e($id); ?>" name="id">
                                <div class="single-box">
                                    <label for="">Middle name</label><br>
                                    <input style="text-transform: uppercase;" type="gmail" value="<?php echo e($contact->gmail); ?>" name="gmail">
                                    <p style="color: red" ><?php $__errorArgs = ['gmail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                </div>
                                <div class="twoFlex">
                                    <div class="box">
                                        <label for="">Street Address</label><br>
                                        <input style="text-transform: uppercase;" type="text" value="<?php echo e($contact->street); ?>" name="street">
                                    <p style="color: red" ><?php $__errorArgs = ['street'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    </div>
                                    <div class="box">
                                        <label for="">City</label><br>
                                        <input style="text-transform: uppercase;" type="text" value="<?php echo e($contact->city); ?>" name="city">
                                    <p style="color: red" ><?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    </div>
                                    <div class="box">
                                        <label for="">State</label><br>
                                        <input style="text-transform: uppercase;" type="text" value="<?php echo e($contact->state); ?>" name="state">
                                    <p style="color: red" ><?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    </div>
                                </div>
                                <div class="twoFlex">
                                    <div class="box">
                                        <label for="">Postal Code</label><br>
                                        <input style="text-transform: uppercase;" type="text" value="<?php echo e($contact->postal); ?>" name="postal">
                                    <p style="color: red" ><?php $__errorArgs = ['postal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    </div>
                                    <div class="box">
                                        <label for="">Country</label><br>
                                        <input style="text-transform: uppercase;" type="text" value="<?php echo e($contact->country); ?>" name="country">
                                    <p style="color: red" ><?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></p>
                                    </div>
                                </div>
                                
                                <button style="float: right;" type="submit" class="btn btn-primary btn-sm">Save Changes</button>
                            </form>
                        </div>
                    </div>

                    <div class="contact"  id="Background">
                        <p class="p2">Background</p>
                        <div class="form-contact">
                            <form action="<?php echo e(route('admin-adminBack')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                
                                <input style="text-transform: uppercase;" type="hidden" value="<?php echo e($id); ?>" name="id">
                                <div class="twoFlex">
                                    <div class="box">
                                        <label for="">Elementary Education</label><br>
                                        <input style="text-transform: uppercase;" type="text" value="<?php echo e($background->elem); ?>" name="elem">
                                    </div>
                                    <div class="box">
                                        <label for="">Year Graduate</label><br>
                                        <input style="text-transform: uppercase;" type="number" value="<?php echo e($background->elemYear); ?>" name="elemYear">
                                    </div>
                                </div>
                                <div class="twoFlex">
                                    <div class="box">
                                        <label for="">Junior High School</label><br>
                                        <input style="text-transform: uppercase;" type="text" value="<?php echo e($background->junior); ?>" name="junior">
                                    </div>
                                    <div class="box">
                                        <label for="">Year Graduate</label><br>
                                        <input style="text-transform: uppercase;" type="number" value="<?php echo e($background->juniorYear); ?>" name="juniorYear">
                                    </div>
                                </div>
                                
                                <button style="float: right;" type="submit" class="btn btn-primary btn-sm">Save Changes</button>
                            </form>
                        </div>
                    </div>

                    <div class="contact" id="Question">
                        <p class="p2">Question</p>
                        <div class="form-contact">
                            <form action="" method="post">
                                <div class="single-box">
                                    <label for="">Strand </label><br>
                                    <select name="" id="">
                                        <option value=""><?php echo e($ask->year); ?></option>
                                    </select>
                                </div>
                                <div class="single-box">
                                    <label for="">Year Graduate</label><br>
                                    <select name="" id="">
                                        <option value=""><?php echo e($ask->year); ?></option>
                                    </select>
                                    
                                </div>

                                <div class="single-box">
                                    <label for="">Did you proceed to college ? </label><br>
                                    <select name="" id="">
                                        <option value=""><?php echo e($ask->proceed); ?></option>
                                    </select>
                                </div>

                                
                                <div class="single-box">
                                    <label for="">Name of School</label><br>
                                    <input style="text-transform: uppercase;" type="text" value="<?php echo e($ask->collegeName); ?>">
                                </div>

                                <div class="single-box">
                                    <label for="">Is your STRAND related to a course in college ? </label><br>
                                    <select name="" id="">
                                        <option value=""><?php echo e($ask->related); ?></option>
                                    </select>
                                </div>
<!--                                 
                                <button style="float: right;" type="submit" class="btn btn-primary btn-sm">Save Changes</button> -->
                            </form>
                        </div>
                    </div>

                    <!-- <div class="contact" id="account">
                        <p class="p2">Account</p>
                        <div class="form-contact">
                            <form action="">
                                <div class="single-box">
                                    <label for="">Username</label><br>
                                    <input style="text-transform: uppercase;" type="text">
                                </div>

                                <div class="single-box">
                                    <label for="">Password</label><br>
                                    <input style="text-transform: uppercase;" type="text">
                                </div>

                                <div class="single-box">
                                    <label for="">Repeat Password</label><br>
                                    <input style="text-transform: uppercase;" type="text">
                                </div>
                                
                                <button style="float: right;" type="submit" class="btn btn-primary btn-sm">Save Changes</button>
                            </form>
                        </div>
                    </div> -->



                </div>

            </div>
        </div>
    </div>

    
<script>
    const tog = document.getElementById('tog');
    const show = document.querySelector('.show');

    tog.addEventListener('click', () => {
        if (show.style.display === 'none' || show.style.display === '') {
            show.style.display = 'block';
        } else {
            show.style.display = 'none';
        }
    });
</script>

<script>
    // Get a reference to the input element
    const inputElement = document.getElementById('uppercaseInput');

    // Add an event listener to the input element
    inputElement.addEventListener('input', function() {
        // Convert the input value to uppercase
        this.value = this.value.toUpperCase();
    });
</script>


<script>
        // Function to update the image when a new file is selected
        function updateImage() {
            const imageInput = document.getElementById('imageInput');
            const profileImage = document.getElementById('profileImage');
            
            if (imageInput.files && imageInput.files[0]) {
                const reader = new FileReader();

                reader.onload = function(e) {
                    profileImage.src = e.target.result;
                }

                reader.readAsDataURL(imageInput.files[0]);
            }
        }
    </script>
   
</body>
</html><?php /**PATH C:\FinalIsabida\resources\views/admin/admin-adminPerson.blade.php ENDPATH**/ ?>