<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\users;
use Hash;
use Illuminate\Support\Str;
use App\Models\contact;
use App\Models\randomKey;
use App\Models\user;
use Illuminate\Validation\Rule;

class login extends Controller
{

    public function login () {
        if (session('user_role') === 'admin') {
            return view('admin/admin-home');
        } elseif(session('user_role') === 'user')  {
            return view('user/user-userHomeMain');
        } else {
            return view('login');
        }
       
    }

    public function forget() {
        return view('forget');
    }

    public function forgetCode() {
        return view('forgetCode');
    }

    public function forgetCheck() {
        return view('forgetCheck');
    }

    public function loginValidate (Request $request) {
        $request->validate([
            'username' => 'required',
            'password' => 'required',
        ]);
        
        // $user = users::where('username', '=', $request->username)->first();
        $user = users::where('username', $request->username)->where('status', '0')->first();

        if ($user && Hash::check($request->password, $user->password)) {

            if ($user->role === '1') {
                session(['user_role' => 'admin']);
                session(['users' => $user]);
                return redirect()->route('admin-adminHome');
            } elseif( $user->role === '0' ) {
                session(['user_role' => 'user']);
                session(['users' => $user]);
                return redirect()->route('user-userHomeMain');
            }

        } else {
            return redirect()->route('login-login');
        }
    }

    public function logout() {

        session()->forget('user_role');
        session()->forget('user');
        // Perform other logout actions
        return redirect()->route('login-login');
    }


    public function forgerValidate (Request $request) {
        $request->validate([
            'gmailAcc' => 'required'
        ]);

        $contacts = contact::where('gmail', $request->gmailAcc)->first();

        $randomString = Str::random(10);

        if($contacts){
            $randomKey = randomKey::where('userId', $contacts->userId)->first();

            $mail_data = [
                'recipient' => 'rolanjayisabida46@gmail.com',
                'fromEmail' => $request->gmailAcc,
                'fromName'  => 'Gingoog City Colleges',
                'subject'   => 'SHS Alumni Profiling System',
                'body'      => $randomString
            ];

            \Mail::send('email_template', $mail_data, function($message) use ($mail_data){

                $message->to($mail_data['recipient'])
                        ->from($mail_data['fromEmail'])
                        ->subject($mail_data['subject']);

            });

            

            if($randomKey) {
                $randomKey->keyRandom = $randomString;
                $randomKey->userId = $contacts->userId;
                $randomKey->save();

                return view('forgetCode', compact('contacts'));
            } else {
                $randomKey = new randomKey();
                $randomKey->keyRandom = $randomString;
                $randomKey->userId = $contacts->userId;
                $randomKey->save();
                return view('forgetCode', compact('contacts'));
            }
           
        } else {
            return back()->with('failed', 'The email entered does not exist in our system');
        }

    }

    public function codeEmail (Request $request) {

        $request->validate([
            'code' => 'required',
            'id' => 'required'
        ]);

        $code =  $request->code;
        $id = $request->id;
        $randomKey = randomKey::where('userId', $request->id)->first();

      
        if($randomKey) {

            if($randomKey->keyRandom ==  $code){
                return view('forgetCheck', compact('id'));
            }
            else {
                return view('login');
            }

        }

        return redirect()->route('login')->withErrors($validator);

    }

    public function changePass (Request $request) {
        $request->validate([
            'id' => 'required',
            'newPassword' => 'required',
        ]);

        // dd($request->all());
        $users = user::where('id', $request->id)->first();
        $users->password = Hash::make($request->newPassword);
        $users->save();
        return redirect()->route('login-login')->with('save', 'Password has been save');

    }


}
