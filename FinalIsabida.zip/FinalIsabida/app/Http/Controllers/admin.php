<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\users;
use App\Models\profile;
use App\Models\ask;
use App\Models\strand;
use App\Models\background;
use App\Models\contact;
use App\Models\course;
use DB;
use Hash;
use Illuminate\Support\Facades\File;

use Illuminate\Validation\Rule;

class admin extends Controller
{

    public function adminHome () {
        
        $profiles = Profile::limit(6)->get();
        $strandCounts = DB::table('strands')
        ->leftJoin('asks', 'strands.id', '=', 'asks.strand')
        ->select('strands.id', 'strands.strand', DB::raw('COUNT(asks.userId) as user_count'))
        ->where('strands.status', 0)
        ->groupBy('strands.id', 'strands.strand')
        ->get();
        return view('admin/admin-home', compact('profiles', 'strandCounts'));

    }


    public function adminSettings() {
        $users = users::where('id', session('users')->id)->first();
        $contact = contact::where('userId', session('users')->id)->first();
        return view('admin/admin-settings', compact('users', 'contact'));
    }

    public function profile () {
        $profilesAndAsks = DB::table('profiles')
        ->join('asks', 'profiles.userId', '=', 'asks.userId')
        ->select('profiles.*', 'asks.year')
        ->get();
        
        return view('admin/admin-profile', compact('profilesAndAsks'));
    }

    public function strandProfile ($id) {
        $profiles = DB::table('profiles')
        ->join('users', 'profiles.userId', '=', 'users.id')
        ->join('asks', 'profiles.userId', '=', 'asks.userId')
        ->select('profiles.*', 'asks.year')
        ->where('asks.strand', '=', $id)
        ->get();

       $strand = strand::where('id', $id)->first();
        
        return view('admin/admin-strandProfile', compact('profiles', 'strand'));
    }

    public function question () {
        $strandCounts = DB::table('strands')
        ->leftJoin('asks', 'strands.id', '=', 'asks.strand')
        ->select(
            'strands.strand as strand_name',
            DB::raw('COUNT(asks.id) as total_users'), // Calculate total users without conditions
            DB::raw('COUNT(CASE WHEN asks.proceed = "yes" THEN 1 END) as proceed_yes'), // Count "yes" in proceed
            DB::raw('COUNT(CASE WHEN asks.proceed = "no" THEN 1 END) as stop_schooling'), // Count "no" in proceed
            DB::raw('COUNT(CASE WHEN asks.related = "yes" THEN 1 END) as related_yes'), // Count "yes" in related
            DB::raw('COUNT(CASE WHEN asks.related = "no" THEN 1 END) as not_related') // Count "no" in related
        )
        ->where('strands.status', 0)
        ->where('strands.strand', '!=', 'TEMP')
        ->groupBy('strands.strand')
        ->get();
    
        $enrolledCount = Ask::where('collegeName', 'yes')->count();
        $notEnrolledCount = Ask::where('collegeName', '!=', 'yes')->count();

        $countYesCourses = course::where('asnwer', 'yes')
        ->groupBy('course')
        ->selectRaw('course, count(*) as count')
        ->get();

        return view('admin/admin-question', compact('strandCounts', 'enrolledCount', 'notEnrolledCount', 'countYesCourses'));
    }

    public function adminUser () {

        $users = DB::table('users')
            ->leftJoin('profiles', 'users.id', '=', 'profiles.userId')
            ->select('users.id as userId', 'users.username', 'users.role', 'users.status', DB::raw('COALESCE(profiles.firstname, "Pending") as firstname'), DB::raw('COALESCE(profiles.lastname, "Pending") as lastname'))
            ->where('users.role', '=', 0)
            ->where('users.status', '=', 0)
            ->orderBy('users.id', 'asc') // Sort by 'id' in descending order (most recent first)
            ->get();


        return view('admin/admin-adminUser', compact('users'));
    }

    public function adminUserUpdate ($id) {
        $users = users::find($id);
        return view('admin/admin-adminUserUpdate', compact('users'));
    }

    public function adminStrand () {
        $strands = strand::where('status', 0)->get();
        return view('admin/admin-adminStrand', compact('strands'));
    }

    //view
    public function UpdateStrandView ($id) {
        $strand = strand::find($id);
        return view('admin/admin-UpdateStrandView', compact('strand'));
    }

    //update
    public function deleteStrand ($id) {
        $strand = strand::find($id);
        $strand->status = 1;
        $strand->save();
        return back()->with('updated', 'User has been remove');
    }

    public function adminPerson ($id) {
        $profile = profile::where('userId', $id)->first();
        $contact = contact::where('userId', $id)->first();
        $ask = ask::where('userId', $id)->first();
        $background = background::where('userId', $id)->first();
        return view('admin/admin-adminPerson', compact('profile', 'contact', 'ask', 'background', 'id'));
    }

    public function reportView($strandName) {


        $strandCounts = DB::table('strands')
            ->leftJoin('asks', 'strands.id', '=', 'asks.strand')
            ->select(
                'strands.strand as strand_name',
                DB::raw('COUNT(asks.id) as total_users'), // Calculate total users without conditions
                DB::raw('COUNT(CASE WHEN asks.proceed = "yes" THEN 1 END) as proceed_yes'), // Count "yes" in proceed
                DB::raw('COUNT(CASE WHEN asks.proceed = "no" THEN 1 END) as stop_schooling'), // Count "no" in proceed
                DB::raw('COUNT(CASE WHEN asks.related = "yes" THEN 1 END) as related_yes'), // Count "yes" in related
                DB::raw('COUNT(CASE WHEN asks.related = "no" THEN 1 END) as not_related') // Count "no" in related
            )
            ->where('strands.status', 0)
            ->where('strands.strand', $strandName)
            ->groupBy('strands.strand')
            ->get();

        $enrolledCount = Ask::where('collegeName', 'yes')->count();
        $notEnrolledCount = Ask::where('collegeName', '!=', 'yes')->count();
        return view('admin/admin-reportView', compact('strandCounts', 'enrolledCount', 'notEnrolledCount'));
    }

    public function reportView2() {
        
        $enrolledCount = Ask::where('collegeName', 'yes')->count();
        $notEnrolledCount = Ask::where('collegeName', '!=', 'yes')->count();
        return view('admin/admin-reportView2', compact('enrolledCount', 'notEnrolledCount'));
    }

    public function reportView3() {
        $countYesCourses = course::where('asnwer', 'yes')
        ->groupBy('course')
        ->selectRaw('course, count(*) as count')
        ->get();

        return view('admin/admin-reportView3', compact('countYesCourses'));
    }


    public function addUser(Request $request) {
        
        $request->validate([
            'username' => 'required|unique:users|max:30',
            'password' => 'required',
        ]);
        
        $users = new users();
        $users->username = $request->username;
        $users->password = Hash::make($request->password);
        $users->role     = 0;
        $users->status   = 0;
        $users->save();
        return back()->with('success', 'Data has been saved.');
    }

    public function deleteUser ($id) {
        $user = users::find($id);
        $user->status = 1;
        $user->save();
        return back()->with('updated', 'User has been remove');
    }


    
    public function userUpdate(Request $request) {
        $request->validate([
            'username' => 'required|max:30',
            'password' => 'required',
        ]);

        $user = users::find($request->id);
        $user->username = $request->username; 
        $user->password = Hash::make($request->password);
        $user->save();
        return back()->with('success', 'Data has been saved.');
        
    }
        

    public function addStrand (Request $request) {
        
        $request->validate([
            'acronym' => 'required|unique:strands',
            'strand' => 'required|unique:strands',
        ]);

        $strands = new strand();
        $strands->acronym = strtoupper($request->acronym);
        $strands->strand =  strtoupper($request->strand);
        $strands->status   = 0;
        $strands->save();
        return back()->with('success', 'Data has been saved.');

    }

    public function newStrand (Request $request) {
        $request->validate([
            'acronym' => 'required',
            'strand' => 'required',
        ]);
        
        $strand = strand::find($request->id);
        $strand->acronym = strtoupper($request->acronym);
        $strand->strand =  strtoupper($request->strand);
        $strand->save();
        return back()->with('success', 'Data has been saved.');

    }

    public function addContact (Request $request) {
       
        // "id" => "5"
        // "gmail" => "marlon@gmail.com"
        // "street" => "P3, Brgy. Agay-Ayan"
        // "city" => "Gingoog City"
        // "state" => "Misamis Oriental"
        // "postal" => "9014"
        // "country" => "Philippines"
        $request->validate([
            'gmail' => 'required',
            'id' => 'required',
            'street' => 'required',
            'city' => 'required',
            'state' => 'required',
            'postal' => 'required',
            'country' => 'required',
        ]);

        
        $contact = contact::where('userId', $request->id)->first();
        $contact->gmail = $request->gmail;
        $contact->street = $request->street;
        $contact->city = $request->city;
        $contact->state = $request->state;
        $contact->postal = $request->postal;
        $contact->country = $request->country;
        $contact->save();
        return back()->with('success', 'Data has been saved.');

    }

    
    
    public function adminBack (Request $request) { 
        $request->validate([
            'elem' => 'required',
            'id' => 'required',
            'elemYear' => 'required',
            'junior' => 'required',
            'juniorYear' => 'required',
        ]);

        
        $background = background::where('userId', $request->id)->first();
        $background->elem = $request->elem;
        $background->elemYear = $request->elemYear;
        $background->junior = $request->junior;
        $background->juniorYear = $request->juniorYear;
        $background->save();
        return back()->with('success', 'Data has been saved.');

    }

     
    public function addPersonal (Request $request) { 
        $request->validate([
            'firstname' => 'required',
            'id' => 'required',
            'middlename' => 'required',
            'lastname' => 'required',
            'birth' => 'required',
            'gender' => 'required',
            'selfStatus' => 'required',
        ]);

        
        $profile = profile::where('userId', $request->id)->first();
        $profile->firstname = $request->firstname;
        $profile->middlename = $request->middlename;
        $profile->lastname = $request->lastname;
        $profile->birth = $request->birth;
        $profile->gender = $request->gender;
        $profile->selfStatus = $request->selfStatus;
        $profile->save();
        return back()->with('success', 'Data has been saved.');

    }


    public function uploadProfile(Request $request)
    {
        $request->validate([
            'photo' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);
    
        // Store the uploaded image in the 'public/photos' directory
        $imagePath = $request->file('photo')->store('public/photos');
    
        // Retrieve the user's profile based on the user's ID in the session
        $profile = Profile::where('userId', $request->id)->first();
    
        if ($profile !== null) {
            // Get the file name with extension from the full image path
            $imageNameWithExtension = pathinfo($imagePath, PATHINFO_BASENAME);
    
            // Update the 'photo' (or 'profile') field with the file name and extension
            $profile->profile = $imageNameWithExtension;
            $profile->save();
    
            // Optionally, you can delete the old profile photo if needed
            // Storage::delete('public/photos/' . $profile->profile);
    
            return back()->with('success', 'Change password successfully');
        }


    }




    public function newPass(Request $request){
            
        $request->validate([
            'username' => 'required',
            'password' => 'required',
            'repeatPassword' => [
                'required',
                Rule::in([$request->input('password')]), // Check if repeatPassword matches password
            ],
        ]);

        
        $users = users::where('id', session('users')->id)->first();
        $users->username = $request->username;
        $users->password = Hash::make($request->password);
        $users->save();
        return back()->with('success', 'Change password successfully');


    }



    public function importData(Request $request)
    {
        $request->validate([
            'csv_file' => 'required|file|mimes:csv,txt',
        ]);

        // Get the uploaded file
        $uploadedFile = $request->file('csv_file');

        // Generate a unique filename
        $filename = time() . '_' . $uploadedFile->getClientOriginalName();

        // Move the uploaded file to a directory within your application
        $destinationPath = public_path('uploads'); // Change this to your preferred storage location
        $uploadedFile->move($destinationPath, $filename);

        // Now, you can use the path to the uploaded file for further processing
        $csvFilePath = $destinationPath . '/' . $filename;

        // Parse and process the CSV data
        $csvData = file_get_contents($csvFilePath);
        $rows = explode(PHP_EOL, $csvData);

        foreach ($rows as $row) {
            $rowData = str_getcsv($row);

            if (count($rowData) < 2) {
                // Handle the case where the row doesn't have enough data
                continue;
            }

            // Check if the username already exists
            $existingUser = Users::where('username', $rowData[0])->first();
            if ($existingUser) {
                // Handle the case where the username already exists
                // You can log an error, skip the row, or take appropriate action
                continue;
            }

            // Validate the unique constraint using Laravel validation rulesphp artisan serve
            $request->validate([
                'username' => 'unique:users,username',
            ]);

            // Create a new record in the database
            Users::create([
                'username' => $rowData[0],
                'password' => Hash::make($rowData[1]),
                'status' => 0,
                'role' => 0,
            ]);
        }

        // Optionally, you can redirect the user with a success message
        return back()->with('success', 'Data imported successfully.');
    }
    




    public function saveEmail(Request $request){
        $request->validate([
            'email' => [
                'required',
                Rule::unique('contacts', 'gmail')->where('userId', session('users')->id),
            ],
        ]);

        $contacts = contact::where('userId', session('users')->id)->first();

        if ($contacts) {
            $contacts->gmail = $request->email;
            $contacts->save();
            return back()->with('success', 'Updated Successfully');
        }
        
        $contact = new contact();
        $contact->gmail = $request->email;
        $contact->userId = session('users')->id;
        $contact->save();
        
        return back()->with('success', 'Save Successfully');

    }






}
