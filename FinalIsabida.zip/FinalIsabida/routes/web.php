<?php

use Illuminate\Support\Facades\Route;
use  App\Http\Controllers\user;
use  App\Http\Controllers\admin;
use  App\Http\Controllers\login;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::middleware(['user'])->group(function () {
    //user
    Route::get('user-home', [user::class, 'userHome'])->name('user-home');
    Route::get('user-userHomeMain', [user::class, 'userHomeMain'])->name('user-userHomeMain');
    Route::get('user-usertAlertOne', [user::class, 'usertAlertOne'])->name('user-usertAlertOne');
    Route::get('user-usertAlertTwo', [user::class, 'usertAlertTwo'])->name('user-usertAlertTwo');
    Route::get('user-usertAlertThree', [user::class, 'usertAlertThree'])->name('user-usertAlertThree');
    Route::get('user-usertAlertFour', [user::class, 'usertAlertFour'])->name('user-usertAlertFour');
    
    Route::post('user-userAgree', [user::class, 'userAgree'])->name('user-userAgree');
    Route::post('user-userAsk', [user::class, 'userAsk'])->name('user-userAsk');
    Route::post('user-userProfile', [user::class, 'userProfile'])->name('user-userProfile');
    Route::post('user-userProfile2', [user::class, 'userProfile2'])->name('user-userProfile2');
    Route::post('user-userContact', [user::class, 'userContact'])->name('user-userContact');
    Route::post('user-userAskTwo', [user::class, 'userAskTwo'])->name('user-userAskTwo');
    Route::post('user-userBack', [user::class, 'userBack'])->name('user-userBack');
    Route::post('user-userAccount', [user::class, 'userAccount'])->name('user-userAccount');
    Route::post('user-uploadProfile', [user::class, 'uploadProfile'])->name('user-uploadProfile');
    Route::post('user-userCourse', [user::class, 'userCourse'])->name('user-userCourse');

});



Route::middleware(['admin'])->group(function () {
    //admin
    Route::get('admin-adminHome', [admin::class, 'adminHome'])->name('admin-adminHome');
    Route::get('admin-adminSettings', [admin::class, 'adminSettings'])->name('admin-adminSettings');
    Route::get('admin-profile', [admin::class, 'profile'])->name('admin-profile');
    Route::get('admin-strandProfile/{id}', [admin::class, 'strandProfile'])->name('admin-strandProfiles');
    Route::get('admin-question', [admin::class, 'question'])->name('admin-question');
    Route::get('admin-adminUser', [admin::class, 'adminUser'])->name('admin-adminUser');

    Route::get('admin-adminStrand', [admin::class, 'adminStrand'])->name('admin-adminStrand');
    Route::get('admin-adminPerson/{id}', [admin::class, 'adminPerson'])->name('admin-adminPerson');


    Route::post('admin-addUser', [admin::class, 'addUser'])->name('admin-addUser');
    Route::post('admin-userUpdate', [admin::class, 'userUpdate'])->name('admin-userUpdate');
    Route::get('admin-deleteUser/{id}', [admin::class, 'deleteUser'])->name('admin-deleteUser');
    Route::get('admin-adminUserUpdate/{id}', [admin::class, 'adminUserUpdate'])->name('admin-adminUserUpdate');
    Route::get('admin-reportView/{name}', [admin::class, 'reportView'])->name('admin-reportView');
    Route::get('admin-reportView2', [admin::class, 'reportView2'])->name('admin-reportView2');
    Route::get('admin-reportView3', [admin::class, 'reportView3'])->name('admin-reportView3');

    Route::post('admin-addStrand', [admin::class, 'addStrand'])->name('admin-addStrand');
    Route::post('admin-newStrand', [admin::class, 'newStrand'])->name('admin-newStrand');
    Route::get('admin-UpdateStrandView/{id}', [admin::class, 'UpdateStrandView'])->name('admin-UpdateStrandView');
    Route::get('admin-deleteStrand/{id}', [admin::class, 'deleteStrand'])->name('admin-deleteStrand');
    Route::post('admin-addContact', [admin::class, 'addContact'])->name('admin-addContact');
    Route::post('admin-adminBack', [admin::class, 'adminBack'])->name('admin-adminBack');
    Route::post('admin-addPersonal', [admin::class, 'addPersonal'])->name('admin-addPersonal');
    Route::post('admin-uploadProfile', [admin::class, 'uploadProfile'])->name('admin-uploadProfile');
    Route::post('admin-newPass', [admin::class, 'newPass'])->name('admin-newPass');
    Route::post('admin-importData', [admin::class, 'importData'])->name('admin-importData');
    Route::post('admin-saveEmail', [admin::class, 'saveEmail'])->name('admin-saveEmail');

});

//login
Route::get('/', [login::class, 'login'])->name('login-login');
Route::post('loginValidate', [login::class, 'loginValidate'])->name('loginValidate');
Route::get('logout', [login::class, 'logout'])->name('logout');
Route::get('forget', [login::class, 'forget'])->name('forget');
Route::get('forgetCheck', [login::class, 'forgetCheck'])->name('forgetCheck');
Route::get('forgetCode', [login::class, 'forgetCode'])->name('forgetCode');

Route::post('forgerValidate', [login::class, 'forgerValidate'])->name('forgerValidate');
Route::post('codeEmail', [login::class, 'codeEmail'])->name('codeEmail');
Route::post('changePass', [login::class, 'changePass'])->name('changePass');

